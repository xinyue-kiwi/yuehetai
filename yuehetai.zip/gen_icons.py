# 纯标准库生成月禾台 PWA 图标（无需 Pillow / 网络）
import struct, zlib, math, os

def new_buf(w, h):
    # RGBA buffer, 初始全透明
    return [[0, 0, 0, 0] for _ in range(w * h)], w, h

def set_px(buf, w, h, x, y, c):
    if 0 <= x < w and 0 <= y < h:
        i = y * w + x
        buf[i] = list(c)

def fill_rect(buf, w, h, x0, y0, x1, y1, c):
    for y in range(int(y0), int(y1)):
        for x in range(int(x0), int(x1)):
            set_px(buf, w, h, x, y, c)

def fill_circle(buf, w, h, cx, cy, r, c):
    for y in range(int(cy - r), int(cy + r) + 1):
        for x in range(int(cx - r), int(cx + r) + 1):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                set_px(buf, w, h, x, y, c)

def round_corner_cut(buf, w, h, rad):
    # 将四角透明化，形成圆角矩形
    for y in range(h):
        for x in range(w):
            corner = None
            if x < rad and y < rad: corner = (rad - x, rad - y)
            elif x >= w - rad and y < rad: corner = (x - (w - rad), rad - y)
            elif x < rad and y >= h - rad: corner = (rad - x, y - (h - rad))
            elif x >= w - rad and y >= h - rad: corner = (x - (w - rad), y - (h - rad))
            if corner:
                dx, dy = corner
                if dx * dx + dy * dy > rad * rad:
                    buf[y * w + x] = [0, 0, 0, 0]

GREEN = (63, 158, 126, 255)
DARK = (47, 125, 99, 255)
WHITE = (255, 255, 255, 255)

def make_icon(size, rounded, maskable):
    buf, w, h = new_buf(size, size)
    if maskable:
        # 满铺背景（maskable 需内容在安全距离内，这里整块铺色）
        fill_rect(buf, w, h, 0, 0, w, h, GREEN)
    else:
        fill_rect(buf, w, h, 0, 0, w, h, GREEN)
        round_corner_cut(buf, w, h, size * 0.22)
    # 月亮（白色圆）
    cx, cy = w / 2, h * 0.40
    fill_circle(buf, w, h, cx, cy, size * 0.20, WHITE)
    # 禾苗：三根竖条（白色胶囊），略低于月亮
    bar_w = size * 0.055
    top = h * 0.66
    bot = h * 0.86
    for off in (-size * 0.13, 0, size * 0.13):
        fill_rect(buf, w, h, cx + off - bar_w / 2, top, cx + off + bar_w / 2, bot, WHITE)
    # 顶部小穗（短横）
    fill_rect(buf, w, h, cx - size * 0.20, top - size * 0.03, cx + size * 0.20, top, WHITE)
    return buf, w, h

def write_png(path, buf, w, h):
    raw = bytearray()
    for y in range(h):
        raw.append(0)  # filter type 0
        for x in range(w):
            r, g, b, a = buf[y * w + x]
            raw += bytes((r, g, b, a))
    def chunk(typ, data):
        c = struct.pack('>I', len(data)) + typ + data
        c += struct.pack('>I', zlib.crc32(typ + data) & 0xffffffff)
        return c
    png = b'\x89PNG\r\n\x1a\n'
    png += chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
    png += chunk(b'IDAT', zlib.compress(bytes(raw), 9))
    png += chunk(b'IEND', b'')
    with open(path, 'wb') as f:
        f.write(png)

os.makedirs('icons', exist_ok=True)
for size in (192, 512):
    buf, w, h = make_icon(size, True, False)
    write_png(f'icons/icon-{size}.png', buf, w, h)
buf, w, h = make_icon(512, False, True)
write_png('icons/icon-maskable-512.png', buf, w, h)
print('icons generated:', os.listdir('icons'))
