/**
 * 月禾台 Service Worker
 * 作用：缓存应用外壳（HTML/CSS/JS/图标），让工作台在断网时也能打开，
 *      满足「添加到安卓桌面」后离线可用的体验。
 * 注意：天气数据来自网络 API，离线时会读取上一次缓存，无法实时刷新。
 */
const CACHE_NAME = 'yuehetai-v1';

// 需要预缓存的应用外壳文件（与项目目录结构保持一致）
const SHELL_FILES = [
  './',
  './index.html',
  './styles.css',
  './manifest.webmanifest',
  './js/storage.js',
  './js/utils.js',
  './js/weather.js',
  './js/research.js',
  './js/diet.js',
  './js/accounting.js',
  './js/schedule.js',
  './js/todo.js',
  './js/travel.js',
  './js/menstrual.js',
  './js/settings.js',
  './js/app.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png'
];

// 安装阶段：把所有外壳文件装进缓存
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES))
      .then(() => self.skipWaiting())
  );
});

// 激活阶段：清理旧版本缓存
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

// 请求拦截：优先走缓存（缓存优先策略），保证离线可用
self.addEventListener('fetch', (event) => {
  const req = event.request;
  // 只处理 GET 请求，且跳过第三方天气 API（天气走网络，失败再降级）
  if (req.method !== 'GET') return;
  if (new URL(req.url).hostname.includes('open-meteo.com')) return;

  event.respondWith(
    caches.match(req).then((cached) => {
      // 命中缓存直接返回；否则去网络取，并顺手缓存起来
      return cached || fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(CACHE_NAME).then((c) => c.put(req, copy));
        return res;
      }).catch(() => cached);
    })
  );
});
