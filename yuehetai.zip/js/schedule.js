/* =========================================================================
   模块 5 · 课表
   功能：① 可视化周课表（周一~周日）② 增删课程 ③ 记录课程考核要求
   本地保存：courses
   ========================================================================= */
(function (YH) {
  YH.modules = YH.modules || {};

  const DAYS = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  // 课程配色（点击色块选择）
  const COLORS = ['#3f9e7e', '#4a8fd6', '#e0a23b', '#d96b8b', '#8a6fd6', '#5bb3a6', '#e0794b'];

  YH.modules.schedule = {
    title: '课表',
    desc: '可视化周课表 · 课程考核要求',
    icon: '📅',

    render(c) {
      const u = YH.util;
      const courses = YH.store.get('courses', []);
      // 按星期分组
      const byDay = {};
      DAYS.forEach((_, i) => { byDay[i + 1] = []; });
      courses.forEach((co) => { if (byDay[co.day]) byDay[co.day].push(co); });
      Object.values(byDay).forEach((arr) => arr.sort((a, b) => (a.start || '').localeCompare(b.start || '')));

      let html = `<div class="view">
        <h2 class="view-title">📅 课表</h2>
        <p class="view-desc">可视化周课表，支持增删课程并备注考核要求</p>

        <div class="card">
          <div class="card-title">➕ 添加课程</div>
          <div class="grid grid-2">
            <label class="field"><span>课程名称</span><input type="text" id="cName" placeholder="如：高等数学" /></label>
            <label class="field"><span>星期</span>
              <select id="cDay">${DAYS.map((d, i) => `<option value="${i + 1}">${d}</option>`).join('')}</select>
            </label>
            <label class="field"><span>开始时间</span><input type="time" id="cStart" value="08:00" /></label>
            <label class="field"><span>结束时间</span><input type="time" id="cEnd" value="09:40" /></label>
            <label class="field"><span>地点</span><input type="text" id="cLoc" placeholder="如：教三 301" /></label>
            <label class="field"><span>颜色</span>
              <div class="swatches" id="cColors">
                ${COLORS.map((col, i) => `<div class="swatch ${i === 0 ? 'active' : ''}" data-col="${col}" style="background:${col}"></div>`).join('')}
              </div>
            </label>
          </div>
          <label class="field"><span>考核要求（可选）</span>
            <textarea id="cAss" placeholder="如：平时 30% + 期中 20% + 期末 50%"></textarea>
          </label>
          <div class="btn-row"><button class="btn" id="cAdd">添加课程</button></div>
        </div>

        <div class="card">
          <div class="card-title">🗓️ 本周课表</div>
          <div class="grid" style="grid-template-columns:repeat(7,minmax(88px,1fr));gap:8px;overflow-x:auto">`;
      DAYS.forEach((d, i) => {
        html += `<div>
          <div class="sch-cell head">${d}</div>`;
        byDay[i + 1].forEach((co) => {
          html += `<div class="sch-cell course" style="background:${co.color || COLORS[0]}" data-del-c="${co.id}" title="点击删除">
            <div>${u.esc(co.name)}</div>
            <small>${co.start}-${co.end}</small>
            ${co.location ? `<small>${u.esc(co.location)}</small>` : ''}
            ${co.assessment ? `<small>📌考核</small>` : ''}
          </div>`;
        });
        html += `</div>`;
      });
      html += `</div>
          <div class="meta" style="margin-top:10px">提示：点击课程色块即可删除该课程</div>
        </div>
      </div>`;

      c.innerHTML = html;

      // 颜色选择
      let picked = COLORS[0];
      c.querySelectorAll('#cColors .swatch').forEach((s) => s.addEventListener('click', () => {
        c.querySelectorAll('#cColors .swatch').forEach((x) => x.classList.remove('active'));
        s.classList.add('active'); picked = s.dataset.col;
      }));
      // 添加课程
      c.querySelector('#cAdd').addEventListener('click', () => {
        const name = c.querySelector('#cName').value.trim();
        if (!name) return YH.toast('请填写课程名称');
        const base = YH.store.get('courses', []);
        base.push({
          id: u.uid(), name,
          day: Number(c.querySelector('#cDay').value),
          start: c.querySelector('#cStart').value,
          end: c.querySelector('#cEnd').value,
          location: c.querySelector('#cLoc').value.trim(),
          color: picked,
          assessment: c.querySelector('#cAss').value.trim()
        });
        YH.store.set('courses', base); YH.refresh();
      });
      // 删除（点击课程块）
      c.querySelectorAll('[data-del-c]').forEach((b) => b.addEventListener('click', () => {
        if (confirm('确定删除该课程？')) {
          YH.store.set('courses', YH.store.get('courses', []).filter((x) => x.id !== b.dataset.delC)); YH.refresh();
        }
      }));
    }
  };
})(window.YH);
