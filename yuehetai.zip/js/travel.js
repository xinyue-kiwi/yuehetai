/* =========================================================================
   模块 7 · 旅游
   功能：① 旅行计划（行程总览）② 每日行程 ③ 打包清单
   本地保存：trips / itinerary / packing
   ========================================================================= */
(function (YH) {
  YH.modules = YH.modules || {};

  const state = { tripId: '' }; // 当前选中的旅行

  YH.modules.travel = {
    title: '旅游',
    desc: '旅行计划 · 每日行程 · 打包清单',
    icon: '✈️',

    render(c) {
      const u = YH.util;
      let trips = YH.store.get('trips', []);
      if (!state.tripId && trips.length) state.tripId = trips[0].id;

      let html = `<div class="view">
        <h2 class="view-title">✈️ 旅游</h2>
        <p class="view-desc">规划旅行、安排每日行程、整理打包清单</p>

        <div class="card">
          <div class="card-title">🧳 旅行计划</div>
          <div class="grid grid-2">
            <label class="field"><span>旅行名称</span><input type="text" id="trName" placeholder="如：云南 7 日游" /></label>
            <label class="field"><span>备注</span><input type="text" id="trNote" placeholder="同行人 / 预算等" /></label>
            <label class="field"><span>出发日期</span><input type="date" id="trStart" /></label>
            <label class="field"><span>返程日期</span><input type="date" id="trEnd" /></label>
          </div>
          <div class="btn-row"><button class="btn" id="trAdd">添加旅行</button></div>
          ${trips.length ? `<div style="margin-top:14px">
            <label class="field"><span>选择旅行</span>
              <select id="trSel">${trips.map((t) => `<option value="${t.id}" ${t.id === state.tripId ? 'selected' : ''}>${u.esc(t.name)}</option>`).join('')}</select>
            </label>
          </div>` : ''}
        </div>`;

      if (!trips.length) {
        html += `<div class="empty">先添加一个旅行计划吧 ✈️</div></div>`;
        c.innerHTML = html;
        c.querySelector('#trAdd').addEventListener('click', addTrip);
        return;
      }

      const trip = trips.find((t) => t.id === state.tripId);
      const items = YH.store.get('itinerary', []).filter((x) => x.tripId === state.tripId);
      const pack = YH.store.get('packing', []).filter((x) => x.tripId === state.tripId);
      const packDone = pack.filter((x) => x.checked).length;

      // 当前旅行总览
      html += `<div class="card">
        <div class="card-title">📍 ${u.esc(trip.name)}</div>
        <div class="meta">${trip.start || '未设'} ~ ${trip.end || '未设'}${trip.note ? ' · ' + u.esc(trip.note) : ''}</div>
      </div>`;

      // 每日行程
      html += `<div class="card">
        <div class="card-title">🗺️ 每日行程 <span class="badge tag">${items.length}</span></div>
        <div class="grid grid-2">
          <label class="field"><span>日期</span><input type="date" id="itDate" value="${trip.start || u.today()}" /></label>
          <label class="field"><span>时间</span><input type="time" id="itTime" value="09:00" /></label>
        </div>
        <label class="field"><span>安排内容</span><input type="text" id="itContent" placeholder="如：上午 滇池，下午 石林" /></label>
        <div class="btn-row"><button class="btn" id="itAdd">添加行程</button></div>
        <div style="margin-top:14px">`;
      if (!items.length) html += `<div class="empty">还没有行程安排</div>`;
      items.slice().sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time)).forEach((it) => {
        html += `<div class="item">
          <div class="grow"><div class="title">${u.esc(it.content)}</div>
            <div class="meta">${it.date} ${it.time}</div></div>
          <div class="item-actions"><button class="btn ghost sm" data-del-it="${it.id}">删除</button></div>
        </div>`;
      });
      html += `</div></div>`;

      // 打包清单
      html += `<div class="card">
        <div class="card-title">🎒 打包清单 <span class="badge tag">${packDone}/${pack.length}</span></div>
        <div class="btn-row" style="margin-bottom:12px">
          <input type="text" id="pkItem" placeholder="如：充电宝" style="flex:1" />
          <button class="btn" id="pkAdd">添加</button>
        </div>
        <div id="pkList">`;
      if (!pack.length) html += `<div class="empty">打包清单为空</div>`;
      pack.forEach((p) => {
        html += `<div class="item ${p.checked ? 'done' : ''}">
          <div class="check ${p.checked ? 'on' : ''}" data-toggle-pk="${p.id}">${p.checked ? '✓' : ''}</div>
          <div class="grow"><div class="title">${u.esc(p.item)}</div></div>
          <div class="item-actions"><button class="btn ghost sm" data-del-pk="${p.id}">删除</button></div>
        </div>`;
      });
      html += `</div></div></div>`;

      c.innerHTML = html;

      // 事件
      c.querySelector('#trAdd').addEventListener('click', addTrip);
      c.querySelector('#trSel').addEventListener('change', (e) => { state.tripId = e.target.value; YH.refresh(); });
      c.querySelector('#itAdd').addEventListener('click', () => {
        const content = c.querySelector('#itContent').value.trim();
        if (!content) return YH.toast('请填写行程内容');
        const base = YH.store.get('itinerary', []);
        base.push({ id: u.uid(), tripId: state.tripId, date: c.querySelector('#itDate').value, time: c.querySelector('#itTime').value, content });
        YH.store.set('itinerary', base); YH.refresh();
      });
      c.querySelector('#pkAdd').addEventListener('click', () => {
        const item = c.querySelector('#pkItem').value.trim();
        if (!item) return YH.toast('请填写物品');
        const base = YH.store.get('packing', []);
        base.push({ id: u.uid(), tripId: state.tripId, item, checked: false });
        YH.store.set('packing', base); YH.refresh();
      });
      c.querySelectorAll('[data-del-it]').forEach((b) => b.addEventListener('click', () => {
        YH.store.set('itinerary', YH.store.get('itinerary', []).filter((x) => x.id !== b.dataset.delIt)); YH.refresh();
      }));
      c.querySelectorAll('[data-toggle-pk]').forEach((b) => b.addEventListener('click', () => {
        const p = pack.find((x) => x.id === b.dataset.togglePk);
        if (p) { p.checked = !p.checked; YH.store.set('packing', pack); YH.refresh(); }
      }));
      c.querySelectorAll('[data-del-pk]').forEach((b) => b.addEventListener('click', () => {
        YH.store.set('packing', YH.store.get('packing', []).filter((x) => x.id !== b.dataset.delPk)); YH.refresh();
      }));

      function addTrip() {
        const name = c.querySelector('#trName').value.trim();
        if (!name) return YH.toast('请填写旅行名称');
        const base = YH.store.get('trips', []);
        const id = u.uid();
        base.push({ id, name, start: c.querySelector('#trStart').value, end: c.querySelector('#trEnd').value, note: c.querySelector('#trNote').value.trim() });
        YH.store.set('trips', base); state.tripId = id; YH.refresh();
      }
    }
  };
})(window.YH);
