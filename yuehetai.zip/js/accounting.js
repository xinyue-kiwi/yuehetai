/* =========================================================================
   模块 4 · 记账
   功能：① 收支记账  ② 月度收支统计（含分类占比）
   本地保存：records
   ========================================================================= */
(function (YH) {
  YH.modules = YH.modules || {};

  // 模块内部状态：当前统计月份（YYYY-MM）
  const state = { month: YH.util.today().slice(0, 7) };

  const CATS = {
    expense: ['餐饮', '交通', '购物', '居住', '娱乐', '医疗', '学习', '其他'],
    income: ['工资', '奖学金', '兼职', '理财', '其他']
  };

  YH.modules.accounting = {
    title: '记账',
    desc: '收支记账 · 月度统计',
    icon: '💰',

    render(c) {
      const u = YH.util;
      const month = state.month;
      const records = YH.store.get('records', []).filter((r) => r.date.slice(0, 7) === month);

      const income = records.filter((r) => r.type === 'income').reduce((s, r) => s + r.amount, 0);
      const expense = records.filter((r) => r.type === 'expense').reduce((s, r) => s + r.amount, 0);

      // 分类占比（仅支出）
      const byCat = {};
      records.filter((r) => r.type === 'expense').forEach((r) => {
        byCat[r.category] = (byCat[r.category] || 0) + r.amount;
      });
      const maxCat = Math.max(1, ...Object.values(byCat));

      let html = `<div class="view">
        <h2 class="view-title">💰 记账</h2>
        <p class="view-desc">随手记一笔，月底自动出统计</p>

        <div class="card">
          <label class="field"><span>统计月份</span><input type="month" id="aMonth" value="${month}" /></label>
          <div class="grid grid-3">
            <div class="card kpi"><div class="n" style="color:var(--primary)">${income.toFixed(2)}</div><div class="l">收入</div></div>
            <div class="card kpi"><div class="n" style="color:var(--danger)">${expense.toFixed(2)}</div><div class="l">支出</div></div>
            <div class="card kpi"><div class="n">${(income - expense).toFixed(2)}</div><div class="l">结余</div></div>
          </div>
          <div style="margin-top:8px">
            <div class="meta" style="margin-bottom:8px">支出分类占比</div>
            ${Object.keys(byCat).length ? Object.entries(byCat).map(([k, v]) => `
              <div class="stat-row">
                <div style="width:64px">${u.esc(k)}</div>
                <div class="stat-bar"><span style="width:${(v / maxCat * 100).toFixed(0)}%;background:var(--primary)"></span></div>
                <div class="stat-num">${v.toFixed(2)}</div>
              </div>`).join('') : '<div class="empty">本月暂无支出</div>'}
          </div>
        </div>

        <div class="card">
          <div class="card-title">✍️ 记一笔</div>
          <div class="grid grid-2">
            <label class="field"><span>日期</span><input type="date" id="aDate" value="${u.today()}" /></label>
            <label class="field"><span>类型</span>
              <select id="aType">
                <option value="expense">支出</option>
                <option value="income">收入</option>
              </select>
            </label>
            <label class="field"><span>分类</span>
              <select id="aCat">${CATS.expense.map((x) => `<option>${x}</option>`).join('')}</select>
            </label>
            <label class="field"><span>金额</span><input type="number" id="aAmt" placeholder="0.00" min="0" step="0.01" /></label>
          </div>
          <label class="field"><span>备注（可选）</span><input type="text" id="aNote" placeholder="如：午餐 / 地铁" /></label>
          <div class="btn-row"><button class="btn" id="aAdd">保存记账</button></div>
        </div>

        <div class="card">
          <div class="card-title">📋 ${month} 明细 <span class="badge tag">${records.length} 笔</span></div>
          <div id="aList">`;
      if (!records.length) html += `<div class="empty">本月还没有记账</div>`;
      records.slice().sort((a, b) => b.date.localeCompare(a.date)).forEach((r) => {
        const isIn = r.type === 'income';
        html += `<div class="item">
          <div class="grow">
            <div class="title">${u.esc(r.category)} ${isIn ? '+' : '-'}${Number(r.amount).toFixed(2)}</div>
            <div class="meta">${r.date}${r.note ? ' · ' + u.esc(r.note) : ''}</div>
          </div>
          <div class="item-actions"><button class="btn ghost sm" data-del-a="${r.id}">删除</button></div>
        </div>`;
      });
      html += `</div></div></div>`;

      c.innerHTML = html;

      // 类型切换时更新分类选项
      const typeEl = c.querySelector('#aType');
      const catEl = c.querySelector('#aCat');
      typeEl.addEventListener('change', () => {
        catEl.innerHTML = CATS[typeEl.value].map((x) => `<option>${x}</option>`).join('');
      });
      // 月份切换
      c.querySelector('#aMonth').addEventListener('change', (ev) => {
        state.month = ev.target.value || u.today().slice(0, 7); YH.refresh();
      });
      // 保存
      c.querySelector('#aAdd').addEventListener('click', () => {
        const amount = Number(c.querySelector('#aAmt').value);
        if (!amount || amount <= 0) return YH.toast('请填写有效金额');
        const base = YH.store.get('records', []);
        base.push({
          id: u.uid(),
          date: c.querySelector('#aDate').value || u.today(),
          type: typeEl.value,
          category: catEl.value,
          amount,
          note: c.querySelector('#aNote').value.trim()
        });
        YH.store.set('records', base); YH.refresh();
      });
      c.querySelectorAll('[data-del-a]').forEach((b) => b.addEventListener('click', () => {
        YH.store.set('records', YH.store.get('records', []).filter((r) => r.id !== b.dataset.delA)); YH.refresh();
      }));
    }
  };
})(window.YH);
