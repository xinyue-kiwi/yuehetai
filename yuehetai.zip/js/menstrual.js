/* =========================================================================
   模块 8 · 经期
   功能：① 记录经期（开始/结束日期）② 自动预测下次经期
   预测逻辑：有 ≥2 条记录时按历史平均周期推算；否则使用默认 28 天（可手动调整）
   本地保存：periods / cycleLen
   ========================================================================= */
(function (YH) {
  YH.modules = YH.modules || {};

  YH.modules.menstrual = {
    title: '经期',
    desc: '记录经期 · 自动预测下次',
    icon: '🌸',

    render(c) {
      const u = YH.util;
      const periods = YH.store.get('periods', []).slice().sort((a, b) => b.start.localeCompare(a.start));
      const manualCycle = YH.store.get('cycleLen', null); // 用户手动设定的周期
      const today = u.today();

      // 计算周期长度
      let cycle = 28;
      if (manualCycle) {
        cycle = manualCycle;
      } else if (periods.length >= 2) {
        const asc = periods.slice().sort((a, b) => a.start.localeCompare(b.start));
        let sum = 0;
        for (let i = 1; i < asc.length; i++) sum += u.diffDays(asc[i].start, asc[i - 1].start);
        cycle = Math.round(sum / (asc.length - 1));
      }

      // 预测下次经期
      let predictText = '记录至少一次经期后可预测';
      let daysLeft = null;
      if (periods.length) {
        const last = periods.slice().sort((a, b) => a.start.localeCompare(b.start)).pop();
        const next = u.addDays(last.start, cycle);
        daysLeft = u.diffDays(next, today);
        predictText = `预计 ${next} 开始（${daysLeft >= 0 ? daysLeft + ' 天后' : '已过期 ' + (-daysLeft) + ' 天'}，周期 ${cycle} 天）`;
      }

      let html = `<div class="view">
        <h2 class="view-title">🌸 经期</h2>
        <p class="view-desc">记录经期起止，自动推算下次时间</p>

        <div class="card" style="background:var(--primary-soft);border:none">
          <div class="meta">预测下次经期</div>
          <div style="font-size:18px;font-weight:700;margin-top:4px">${predictText}</div>
        </div>

        <div class="card">
          <div class="card-title">➕ 记录经期</div>
          <div class="grid grid-2">
            <label class="field"><span>开始日期</span><input type="date" id="mStart" value="${today}" /></label>
            <label class="field"><span>结束日期（可选）</span><input type="date" id="mEnd" /></label>
          </div>
          <label class="field"><span>默认周期（天，留空则自动计算）</span>
            <input type="number" id="mCycle" placeholder="如 28" min="15" max="45" value="${manualCycle || ''}" />
          </label>
          <div class="btn-row"><button class="btn" id="mAdd">保存记录</button></div>
        </div>

        <div class="card">
          <div class="card-title">📜 历史记录 <span class="badge tag">${periods.length}</span></div>
          <div id="mList">`;
      if (!periods.length) html += `<div class="empty">还没有记录</div>`;
      periods.forEach((p) => {
        const len = p.end ? u.diffDays(p.end, p.start) + 1 : null;
        html += `<div class="item">
          <div class="grow">
            <div class="title">${p.start}${p.end ? ' → ' + p.end : '（进行中）'}</div>
            <div class="meta">${len ? '持续 ' + len + ' 天' : '未填结束日期'}</div>
          </div>
          <div class="item-actions"><button class="btn ghost sm" data-del-m="${p.id}">删除</button></div>
        </div>`;
      });
      html += `</div></div></div>`;

      c.innerHTML = html;

      c.querySelector('#mAdd').addEventListener('click', () => {
        const start = c.querySelector('#mStart').value;
        const end = c.querySelector('#mEnd').value;
        if (!start) return YH.toast('请选择开始日期');
        if (end && end < start) return YH.toast('结束日期不能早于开始日期');
        const cycleVal = c.querySelector('#mCycle').value;
        // 周期：有填写则保存手动值，否则清除（交回自动计算）
        YH.store.set('cycleLen', cycleVal ? Number(cycleVal) : null);
        const base = YH.store.get('periods', []);
        base.push({ id: u.uid(), start, end: end || '' });
        YH.store.set('periods', base); YH.refresh();
      });
      c.querySelectorAll('[data-del-m]').forEach((b) => b.addEventListener('click', () => {
        YH.store.set('periods', YH.store.get('periods', []).filter((x) => x.id !== b.dataset.delM)); YH.refresh();
      }));
    }
  };
})(window.YH);
