/* =========================================================================
   月禾台 · 主控制器
   职责：注册模块顺序、渲染左侧导航、面板切换（平滑动画）、
        主题换色、轻提示 Toast、Service Worker 注册
   ========================================================================= */
(function (YH) {
  // 模块顺序（对应需求九大功能）
  const ORDER = ['weather', 'research', 'diet', 'accounting', 'schedule', 'todo', 'travel', 'menstrual', 'settings'];

  let current = 'weather';

  // ---- 主题换色：根据主色推导深一档与浅底色，并写入 CSS 变量 ----
  function hexToRgb(hex) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex.split('').map((x) => x + x).join('');
    return { r: parseInt(hex.slice(0, 2), 16), g: parseInt(hex.slice(2, 4), 16), b: parseInt(hex.slice(4, 6), 16) };
  }
  function mix(hex, hex2, amt) {
    const a = hexToRgb(hex), b = hexToRgb(hex2);
    const m = (x, y) => Math.round(x * (1 - amt) + y * amt);
    return `rgb(${m(a.r, b.r)}, ${m(a.g, b.g)}, ${m(a.b, b.b)})`;
  }
  YH.applyTheme = function (hex) {
    const root = document.documentElement.style;
    root.setProperty('--primary', hex);
    root.setProperty('--primary-dark', mix(hex, '#000000', 0.16));
    root.setProperty('--primary-soft', mix(hex, '#ffffff', 0.86));
    // 同步手机状态栏/地址栏颜色
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', hex);
    YH.store.set('theme', hex);
  };

  // ---- 轻提示 Toast ----
  YH.toast = function (msg) {
    let t = document.getElementById('yhToast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'yhToast';
      t.style.cssText = 'position:fixed;left:50%;bottom:40px;transform:translateX(-50%);background:rgba(31,42,36,.92);color:#fff;padding:10px 18px;border-radius:999px;font-size:14px;z-index:999;opacity:0;transition:opacity .25s;pointer-events:none';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.style.opacity = '1';
    clearTimeout(t._timer);
    t._timer = setTimeout(() => { t.style.opacity = '0'; }, 1600);
  };

  // ---- 渲染当前模块 ----
  YH.refresh = function () {
    const mod = YH.modules[current];
    const content = document.getElementById('content');
    if (mod) mod.render(content);
  };

  // ---- 切换模块 ----
  function switchTo(key) {
    current = key;
    // 高亮导航
    document.querySelectorAll('.nav-item').forEach((b) => {
      b.classList.toggle('active', b.dataset.key === key);
    });
    const mod = YH.modules[key];
    document.getElementById('topbarTitle').textContent = mod ? mod.title : '月禾台';
    YH.refresh();
    // 手机端切换后收起抽屉
    closeDrawer();
  }

  // ---- 构建左侧导航 ----
  function buildNav() {
    const nav = document.getElementById('nav');
    nav.innerHTML = ORDER.map((key) => {
      const m = YH.modules[key];
      return `<button class="nav-item ${key === current ? 'active' : ''}" data-key="${key}">
        <span class="ico">${m.icon}</span><span>${m.title}</span>
      </button>`;
    }).join('');
    nav.querySelectorAll('.nav-item').forEach((b) => {
      b.addEventListener('click', () => switchTo(b.dataset.key));
    });
  }

  // ---- 手机端抽屉 ----
  function openDrawer() {
    document.getElementById('sidebar').classList.add('open');
    document.getElementById('sidebarOverlay').classList.add('show');
  }
  function closeDrawer() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('show');
  }

  // ---- 初始化 ----
  function init() {
    // 应用已保存主题
    YH.applyTheme(YH.store.get('theme', '#3f9e7e'));
    buildNav();
    // 默认进入第一个模块
    switchTo('weather');

    // 顶部菜单按钮（手机端）
    document.getElementById('menuBtn').addEventListener('click', openDrawer);
    document.getElementById('sidebarOverlay').addEventListener('click', closeDrawer);

    // 注册 Service Worker（实现「添加到桌面」与离线可用）
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js').catch((e) => console.warn('SW 注册失败：', e));
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})(window.YH);
