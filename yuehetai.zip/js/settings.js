/* =========================================================================
   模块 9 · 设置
   功能：① 自定义主题换色 ② 导出本地数据 ③ 清空本地数据（附带导入）
   本地保存：theme
   ========================================================================= */
(function (YH) {
  YH.modules = YH.modules || {};

  // 预设主题色（含默认「禾绿」）
  const PRESETS = [
    { name: '禾绿', v: '#3f9e7e' },
    { name: '天蓝', v: '#4a8fd6' },
    { name: '晚霞', v: '#e0794b' },
    { name: '樱粉', v: '#d96b8b' },
    { name: '紫罗', v: '#8a6fd6' },
    { name: '暖橙', v: '#e0a23b' }
  ];

  YH.modules.settings = {
    title: '设置',
    desc: '主题换色 · 数据导出 / 清空',
    icon: '⚙️',

    render(c) {
      const cur = YH.store.get('theme', '#3f9e7e');

      let html = `<div class="view">
        <h2 class="view-title">⚙️ 设置</h2>
        <p class="view-desc">自定义外观与本地数据管理</p>

        <div class="card">
          <div class="card-title">🎨 主题换色</div>
          <div class="swatches" id="themeSwatches">
            ${PRESETS.map((p) => `<div class="swatch ${p.v.toLowerCase() === cur.toLowerCase() ? 'active' : ''}" data-color="${p.v}" style="background:${p.v}" title="${p.name}"></div>`).join('')}
          </div>
          <div class="btn-row" style="margin-top:14px">
            <input type="color" id="themePick" value="${cur}" style="width:48px;height:38px;border:none;background:none;padding:0" />
            <button class="btn ghost" id="themeCustom">使用自定义颜色</button>
          </div>
        </div>

        <div class="card">
          <div class="card-title">💾 本地数据</div>
          <p class="meta" style="margin-top:0">所有数据仅保存在本机浏览器中，不会上传服务器。</p>
          <div class="btn-row">
            <button class="btn" id="btnExport">导出数据 (JSON)</button>
            <label class="btn ghost">导入数据
              <input type="file" id="btnImport" accept="application/json" style="display:none" />
            </label>
          </div>
          <div class="btn-row" style="margin-top:14px">
            <button class="btn danger" id="btnClear">清空全部本地数据</button>
          </div>
        </div>

        <div class="card">
          <div class="meta">关于月禾台</div>
          <p class="meta" style="margin-top:6px">一款纯本地、可安装到手机桌面的个人工作台。v1.0</p>
        </div>
      </div>`;

      c.innerHTML = html;

      // 预设色块
      c.querySelectorAll('#themeSwatches .swatch').forEach((s) => s.addEventListener('click', () => {
        YH.applyTheme(s.dataset.color);
        c.querySelectorAll('#themeSwatches .swatch').forEach((x) => x.classList.remove('active'));
        s.classList.add('active');
        YH.toast('主题已更新');
      }));
      // 自定义颜色
      c.querySelector('#themeCustom').addEventListener('click', () => {
        YH.applyTheme(c.querySelector('#themePick').value);
        YH.toast('主题已更新');
        YH.refresh();
      });
      // 导出
      c.querySelector('#btnExport').addEventListener('click', () => {
        const data = YH.store.exportAll();
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = '月禾台数据备份_' + YH.util.today() + '.json';
        a.click();
        YH.toast('数据已导出');
      });
      // 导入
      c.querySelector('#btnImport').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          try {
            const obj = JSON.parse(reader.result);
            YH.store.importAll(obj);
            YH.toast('导入成功，正在刷新'); YH.refresh();
          } catch (err) { YH.toast('文件解析失败'); }
        };
        reader.readAsText(file);
      });
      // 清空
      c.querySelector('#btnClear').addEventListener('click', () => {
        if (confirm('确定清空全部本地数据？此操作不可恢复！')) {
          YH.store.clearAll();
          YH.toast('已清空全部数据'); YH.refresh();
        }
      });
    }
  };
})(window.YH);
