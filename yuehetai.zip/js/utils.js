/* =========================================================================
   月禾台 · 通用工具
   暴露 YH.util
   ========================================================================= */
window.YH = window.YH || {};

YH.util = (function () {
  // 生成唯一 ID（时间戳 + 随机）
  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  // 今天日期字符串 YYYY-MM-DD（按本地时区）
  function today() {
    const d = new Date();
    return fmtDate(d);
  }

  function fmtDate(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  function fmtTime(d) {
    const h = String(d.getHours()).padStart(2, '0');
    const m = String(d.getMinutes()).padStart(2, '0');
    return `${h}:${m}`;
  }

  // HTML 转义，防止用户输入破坏页面
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // 两个 YYYY-MM-DD 相差天数（a - b）
  function diffDays(a, b) {
    const da = new Date(a + 'T00:00:00');
    const db = new Date(b + 'T00:00:00');
    return Math.round((da - db) / 86400000);
  }

  // 给某个日期加 n 天，返回 YYYY-MM-DD
  function addDays(dateStr, n) {
    const d = new Date(dateStr + 'T00:00:00');
    d.setDate(d.getDate() + n);
    return fmtDate(d);
  }

  // 周几中文（0=周日）
  function weekdayCn(d) {
    return ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][d.getDay()];
  }

  // Open-Meteo 使用的 WMO 天气代码 → 中文描述 + emoji
  function weatherInfo(code) {
    const map = {
      0:  ['☀️', '晴'],
      1:  ['🌤️', '大致晴朗'],
      2:  ['⛅', '局部多云'],
      3:  ['☁️', '阴'],
      45: ['🌫️', '雾'],
      48: ['🌫️', '雾凇'],
      51: ['🌦️', '小毛毛雨'],
      53: ['🌦️', '毛毛雨'],
      55: ['🌦️', '大毛毛雨'],
      56: ['🌧️', '冻毛毛雨'],
      57: ['🌧️', '强冻毛毛雨'],
      61: ['🌧️', '小雨'],
      63: ['🌧️', '中雨'],
      65: ['🌧️', '大雨'],
      66: ['🌧️', '冻雨'],
      67: ['🌧️', '强冻雨'],
      71: ['🌨️', '小雪'],
      73: ['🌨️', '中雪'],
      75: ['❄️', '大雪'],
      77: ['🌨️', '雪粒'],
      80: ['🌦️', '小阵雨'],
      81: ['🌦️', '阵雨'],
      82: ['⛈️', '强阵雨'],
      85: ['🌨️', '小阵雪'],
      86: ['🌨️', '大阵雪'],
      95: ['⛈️', '雷阵雨'],
      96: ['⛈️', '雷暴伴冰雹'],
      99: ['⛈️', '强雷暴冰雹']
    };
    return map[code] || ['🌡️', '未知'];
  }

  return { uid, today, fmtDate, fmtTime, esc, diffDays, addDays, weekdayCn, weatherInfo };
})();
