/* =========================================================================
   模块 3 · 运动三餐
   功能：① 每日饮食热量记录  ② 运动记录  ③ 当日热量统计
   本地保存：meals（饮食）、exercises（运动）
   ========================================================================= */
(function (YH) {
  YH.modules = YH.modules || {};

  // 模块内部状态：当前查看的日期
  const state = { date: YH.util.today() };

  const MEAL_TYPES = [
    { v: 'breakfast', t: '早餐' },
    { v: 'lunch', t: '午餐' },
    { v: 'dinner', t: '晚餐' },
    { v: 'snack', t: '加餐' }
  ];

  YH.modules.diet = {
    title: '运动三餐',
    desc: '饮食热量 · 运动消耗 · 当日统计',
    icon: '🍱',

    render(c) {
      const u = YH.util;
      const date = state.date;
      const meals = YH.store.get('meals', []).filter((m) => m.date === date);
      const exes = YH.store.get('exercises', []).filter((e) => e.date === date);

      const intake = meals.reduce((s, m) => s + (Number(m.calories) || 0), 0);
      const burned = exes.reduce((s, e) => s + (Number(e.caloriesBurned) || 0), 0);

      let html = `<div class="view">
        <h2 class="view-title">🍱 运动三餐</h2>
        <p class="view-desc">记录每日饮食与运动，自动统计热量收支</p>

        <div class="card">
          <label class="field"><span>查看日期</span>
            <input type="date" id="dDate" value="${date}" />
          </label>
        </div>

        <div class="grid grid-3">
          <div class="card kpi"><div class="n">${intake}</div><div class="l">摄入 (kcal)</div></div>
          <div class="card kpi"><div class="n">${burned}</div><div class="l">消耗 (kcal)</div></div>
          <div class="card kpi"><div class="n">${intake - burned}</div><div class="l">净热量</div></div>
        </div>`;

      // ---- 饮食记录 ----
      html += `<div class="card">
        <div class="card-title">🍽️ 饮食记录 <span class="badge tag">${meals.length} 条</span></div>
        <div class="grid grid-2">
          <label class="field"><span>餐别</span>
            <select id="mType">${MEAL_TYPES.map((t) => `<option value="${t.v}">${t.t}</option>`).join('')}</select>
          </label>
          <label class="field"><span>食物名称</span><input type="text" id="mName" placeholder="如：鸡胸肉 150g" /></label>
        </div>
        <label class="field"><span>热量 (kcal)</span><input type="number" id="mCal" placeholder="约 200" min="0" /></label>
        <div class="btn-row"><button class="btn" id="mAdd">添加饮食</button></div>
        <div style="margin-top:14px">`;
      if (!meals.length) html += `<div class="empty">今天还没有饮食记录</div>`;
      meals.forEach((m) => {
        const tt = MEAL_TYPES.find((x) => x.v === m.type);
        html += `<div class="item">
          <div class="grow"><div class="title">${u.esc(m.name)}</div>
            <div class="meta">${tt ? tt.t : m.type} · ${m.calories} kcal</div></div>
          <div class="item-actions"><button class="btn ghost sm" data-del-m="${m.id}">删除</button></div>
        </div>`;
      });
      html += `</div></div>`;

      // ---- 运动记录 ----
      html += `<div class="card">
        <div class="card-title">🏃 运动记录 <span class="badge tag">${exes.length} 条</span></div>
        <div class="grid grid-2">
          <label class="field"><span>运动项目</span><input type="text" id="eName" placeholder="如：跑步" /></label>
          <label class="field"><span>时长 (分钟)</span><input type="number" id="eDur" placeholder="30" min="0" /></label>
        </div>
        <label class="field"><span>消耗热量 (kcal)</span><input type="number" id="eCal" placeholder="约 250" min="0" /></label>
        <div class="btn-row"><button class="btn" id="eAdd">添加运动</button></div>
        <div style="margin-top:14px">`;
      if (!exes.length) html += `<div class="empty">今天还没有运动记录</div>`;
      exes.forEach((e) => {
        html += `<div class="item">
          <div class="grow"><div class="title">${u.esc(e.name)}</div>
            <div class="meta">${e.duration} 分钟 · ${e.caloriesBurned} kcal</div></div>
          <div class="item-actions"><button class="btn ghost sm" data-del-e="${e.id}">删除</button></div>
        </div>`;
      });
      html += `</div></div></div>`;

      c.innerHTML = html;

      // 切换日期
      c.querySelector('#dDate').addEventListener('change', (ev) => {
        state.date = ev.target.value || u.today(); YH.refresh();
      });
      // 添加饮食
      c.querySelector('#mAdd').addEventListener('click', () => {
        const name = c.querySelector('#mName').value.trim();
        const cal = Number(c.querySelector('#mCal').value);
        if (!name || !cal) return YH.toast('请填写食物与热量');
        // 注意：meals 是当前日期的子集，追加时必须基于「全部记录」写入，避免丢失其它日期数据
        const base = YH.store.get('meals', []);
        base.push({ id: u.uid(), date, type: c.querySelector('#mType').value, name, calories: cal });
        YH.store.set('meals', base); YH.refresh();
      });
      // 添加运动
      c.querySelector('#eAdd').addEventListener('click', () => {
        const name = c.querySelector('#eName').value.trim();
        const dur = Number(c.querySelector('#eDur').value) || 0;
        const cal = Number(c.querySelector('#eCal').value);
        if (!name || !cal) return YH.toast('请填写运动项目与消耗');
        const base = YH.store.get('exercises', []);
        base.push({ id: u.uid(), date, name, duration: dur, caloriesBurned: cal });
        YH.store.set('exercises', base); YH.refresh();
      });
      // 删除
      c.querySelectorAll('[data-del-m]').forEach((b) => b.addEventListener('click', () => {
        YH.store.set('meals', YH.store.get('meals', []).filter((m) => m.id !== b.dataset.delM)); YH.refresh();
      }));
      c.querySelectorAll('[data-del-e]').forEach((b) => b.addEventListener('click', () => {
        YH.store.set('exercises', YH.store.get('exercises', []).filter((e) => e.id !== b.dataset.delE)); YH.refresh();
      }));
    }
  };
})(window.YH);
