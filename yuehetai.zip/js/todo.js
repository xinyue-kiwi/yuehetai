/* =========================================================================
   模块 6 · 工作（自定义待办清单）
   功能：① 添加 / 勾选完成 / 删除 ② 每条任务设优先级(高/中/低)与截止日期
        ③ 默认「今日待办」按优先级排序 ④ 筛选标签：全部 / 进行中 / 已完成
   本地保存：tasks
   ========================================================================= */
(function (YH) {
  YH.modules = YH.modules || {};

  // 优先级定义与排序权重
  const PRI = {
    high: { t: '高', cls: 'pri-high', w: 3 },
    mid:  { t: '中', cls: 'pri-mid',  w: 2 },
    low:  { t: '低', cls: 'pri-low',  w: 1 }
  };

  // 模块内部状态：当前筛选标签
  const state = { tab: 'today' };

  YH.modules.todo = {
    title: '工作',
    desc: '自定义待办 · 优先级 · 截止日期',
    icon: '📝',

    render(c) {
      const u = YH.util;
      const today = u.today();
      let tasks = YH.store.get('tasks', []);

      // 根据标签筛选
      let list;
      if (state.tab === 'today') {
        // 今日待办：截止日期为今天（含已完成），按优先级排序
        list = tasks.filter((t) => t.due === today);
      } else if (state.tab === 'active') {
        list = tasks.filter((t) => !t.done);
      } else if (state.tab === 'done') {
        list = tasks.filter((t) => t.done);
      } else {
        list = tasks.slice();
      }
      // 按优先级降序（高→低），同优先级按截止日期升序
      list.sort((a, b) => {
        const pa = PRI[a.priority] ? PRI[a.priority].w : 0;
        const pb = PRI[b.priority] ? PRI[b.priority].w : 0;
        if (pb !== pa) return pb - pa;
        return (a.due || '9999').localeCompare(b.due || '9999');
      });

      const TABS = [
        { k: 'today', t: '今日待办' },
        { k: 'all', t: '全部' },
        { k: 'active', t: '进行中' },
        { k: 'done', t: '已完成' }
      ];

      let html = `<div class="view">
        <h2 class="view-title">📝 工作</h2>
        <p class="view-desc">自定义待办清单，支持优先级与截止日期</p>

        <div class="card">
          <label class="field"><span>任务内容</span><input type="text" id="tText" placeholder="今天要做什么？" /></label>
          <div class="grid grid-2">
            <label class="field"><span>优先级</span>
              <select id="tPri">
                <option value="high">高</option>
                <option value="mid" selected>中</option>
                <option value="low">低</option>
              </select>
            </label>
            <label class="field"><span>截止日期</span><input type="date" id="tDue" value="${today}" /></label>
          </div>
          <div class="btn-row"><button class="btn" id="tAdd">添加任务</button></div>
        </div>

        <div class="tabs">`;
      TABS.forEach((tb) => {
        const count = tb.k === 'today' ? tasks.filter((x) => x.due === today).length
          : tb.k === 'all' ? tasks.length
          : tb.k === 'active' ? tasks.filter((x) => !x.done).length
          : tasks.filter((x) => x.done).length;
        html += `<div class="tab ${state.tab === tb.k ? 'active' : ''}" data-tab="${tb.k}">${tb.t} (${count})</div>`;
      });
      html += `</div>`;

      // 任务列表
      if (!list.length) {
        html += `<div class="empty">这里空空如也 🎉</div>`;
      } else {
        list.forEach((t) => {
          const p = PRI[t.priority] || PRI.mid;
          const overdue = !t.done && t.due && t.due < today;
          html += `<div class="item ${t.done ? 'done' : ''}">
            <div class="check ${t.done ? 'on' : ''}" data-toggle="${t.id}">${t.done ? '✓' : ''}</div>
            <div class="grow">
              <div class="title">${u.esc(t.text)}</div>
              <div class="meta">
                <span class="badge ${p.cls}">${p.t}优先级</span>
                ${t.due ? `<span style="margin-left:6px;color:${overdue ? 'var(--danger)' : 'inherit'}">📅 ${t.due}${overdue ? ' 已逾期' : ''}</span>` : '<span style="margin-left:6px">无截止日期</span>'}
              </div>
            </div>
            <div class="item-actions"><button class="btn ghost sm" data-del="${t.id}">删除</button></div>
          </div>`;
        });
      }

      html += `</div>`;
      c.innerHTML = html;

      // 切换标签
      c.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => {
        state.tab = b.dataset.tab; YH.refresh();
      }));
      // 添加
      c.querySelector('#tAdd').addEventListener('click', () => {
        const text = c.querySelector('#tText').value.trim();
        if (!text) return YH.toast('请填写任务内容');
        const base = YH.store.get('tasks', []);
        base.push({
          id: u.uid(), text,
          priority: c.querySelector('#tPri').value,
          due: c.querySelector('#tDue').value,
          done: false, createdAt: Date.now()
        });
        YH.store.set('tasks', base); YH.refresh();
      });
      // 勾选 / 取消
      c.querySelectorAll('[data-toggle]').forEach((b) => b.addEventListener('click', () => {
        const t = tasks.find((x) => x.id === b.dataset.toggle);
        if (t) { t.done = !t.done; YH.store.set('tasks', tasks); YH.refresh(); }
      }));
      // 删除
      c.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', () => {
        YH.store.set('tasks', tasks.filter((x) => x.id !== b.dataset.del)); YH.refresh();
      }));
    }
  };
})(window.YH);
