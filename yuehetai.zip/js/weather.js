/* =========================================================================
   模块 1 · 天气
   功能：输入城市 → 获取实时天气 + 未来 3 天预报（共 4 天格）
   数据来源：Open-Meteo 免费接口（无需密钥），离线时读取上次缓存
   本地保存：城市名、坐标、缓存的天气结果
   ========================================================================= */
(function (YH) {
  YH.modules = YH.modules || {};

  YH.modules.weather = {
    title: '天气',
    desc: '城市天气与未来 3 天预报',
    icon: '🌤️',

    render(c) {
      const data = YH.store.get('weather', { city: '', current: null, daily: [], updated: 0 });
      const u = YH.util;

      // 已保存城市时，直接展示缓存；否则展示搜索框
      let html = `<div class="view">
        <h2 class="view-title">🌤️ 天气</h2>
        <p class="view-desc">输入城市名查询实时天气与未来三天预报（数据来自 Open-Meteo）</p>
        <div class="card">
          <label class="field"><span>城市名称</span>
            <input type="text" id="wCity" placeholder="如：北京 / 上海 / 成都" value="${u.esc(data.city)}" />
          </label>
          <div class="btn-row">
            <button class="btn" id="wSearch">查询天气</button>
            ${data.city ? '<button class="btn ghost" id="wRefresh">刷新</button>' : ''}
          </div>
          <div id="wStatus" class="meta" style="margin-top:10px"></div>
        </div>`;

      if (data.current && data.daily && data.daily.length) {
        const cur = data.current;
        const wi = u.weatherInfo(cur.code);
        html += `<div class="card">
          <div class="weather-now">
            <div class="weather-emoji">${wi[0]}</div>
            <div>
              <div class="weather-temp">${cur.temp}°</div>
              <div class="weather-info">${u.esc(data.city)} · ${wi[1]} · 湿度 ${cur.humidity}% · 风速 ${cur.wind} km/h</div>
              <div class="weather-info">更新于 ${new Date(data.updated).toLocaleString('zh-CN')}</div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="forecast">`;
        data.daily.forEach((d, i) => {
          const dwi = u.weatherInfo(d.code);
          const label = i === 0 ? '今天' : u.weekdayCn(new Date(d.date + 'T00:00:00'));
          html += `<div class="fc-day">
            <div class="d">${label}</div>
            <div class="e">${dwi[0]}</div>
            <div class="t">${d.tmax}° / ${d.tmin}°</div>
            <div class="meta">${dwi[1]}</div>
          </div>`;
        });
        html += `</div></div>`;
      }

      html += `</div>`;
      c.innerHTML = html;

      const cityEl = c.querySelector('#wCity');
      const statusEl = c.querySelector('#wStatus');

      async function doSearch(refresh) {
        const city = (cityEl.value || '').trim();
        if (!city) { statusEl.textContent = '请先输入城市名称'; return; }
        statusEl.textContent = '查询中…';
        try {
          // 1) 城市名 → 经纬度（Open-Meteo 地理编码）
          const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=zh&format=json`);
          const geo = await geoRes.json();
          if (!geo.results || !geo.results.length) {
            statusEl.textContent = '未找到该城市，请检查名称'; return;
          }
          const g = geo.results[0];
          // 2) 经纬度 → 天气预报
          const url = `https://api.open-meteo.com/v1/forecast?latitude=${g.latitude}&longitude=${g.longitude}`
            + `&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m`
            + `&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=4`;
          const wRes = await fetch(url);
          const w = await wRes.json();

          const saved = {
            city: g.name,
            current: {
              temp: Math.round(w.current.temperature_2m),
              humidity: w.current.relative_humidity_2m,
              wind: w.current.wind_speed_10m,
              code: w.current.weather_code
            },
            daily: w.daily.time.map((date, i) => ({
              date,
              code: w.daily.weather_code[i],
              tmax: Math.round(w.daily.temperature_2m_max[i]),
              tmin: Math.round(w.daily.temperature_2m_min[i])
            })),
            updated: Date.now()
          };
          YH.store.set('weather', saved);
          YH.refresh(); // 重新渲染展示结果
        } catch (e) {
          statusEl.textContent = '网络异常，无法获取实时天气（将显示缓存）';
          if (!refresh) console.warn(e);
        }
      }

      c.querySelector('#wSearch').addEventListener('click', () => doSearch(false));
      const rf = c.querySelector('#wRefresh');
      if (rf) rf.addEventListener('click', () => doSearch(true));
    }
  };
})(window.YH);
