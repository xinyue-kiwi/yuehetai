/* =========================================================================
   模块 2 · 科研
   包含：① 科研项目  ② 文献库  ③ 实验待办
   数据全部本地保存
   ========================================================================= */
(function (YH) {
  YH.modules = YH.modules || {};

  YH.modules.research = {
    title: '科研',
    desc: '科研项目 · 文献库 · 实验待办',
    icon: '🔬',

    render(c) {
      const u = YH.util;
      const projects = YH.store.get('projects', []);
      const papers = YH.store.get('papers', []);
      const expTodos = YH.store.get('expTodos', []);

      let html = `<div class="view">
        <h2 class="view-title">🔬 科研</h2>
        <p class="view-desc">管理你的科研项目、文献与实验待办</p>`;

      // ---- ① 科研项目 ----
      html += `<div class="card">
        <div class="card-title">📌 科研项目 <span class="badge tag">${projects.length}</span></div>
        <label class="field"><span>项目名称</span><input type="text" id="pName" placeholder="如：基于深度学习的XX研究" /></label>
        <label class="field"><span>项目描述 / 目标</span><textarea id="pDesc" placeholder="简要记录目标、进展…"></textarea></label>
        <div class="btn-row"><button class="btn" id="pAdd">添加项目</button></div>
        <div id="pList" style="margin-top:14px">`;
      if (!projects.length) html += `<div class="empty">还没有项目，添加第一个吧</div>`;
      projects.slice().reverse().forEach((p) => {
        html += `<div class="item">
          <div class="grow">
            <div class="title">${u.esc(p.name)}</div>
            ${p.desc ? `<div class="meta">${u.esc(p.desc)}</div>` : ''}
          </div>
          <div class="item-actions"><button class="btn ghost sm" data-del-p="${p.id}">删除</button></div>
        </div>`;
      });
      html += `</div></div>`;

      // ---- ② 文献库 ----
      html += `<div class="card">
        <div class="card-title">📚 文献库 <span class="badge tag">${papers.length}</span></div>
        <div class="grid grid-2">
          <label class="field"><span>标题</span><input type="text" id="paTitle" placeholder="论文标题" /></label>
          <label class="field"><span>作者</span><input type="text" id="paAuthor" placeholder="作者" /></label>
          <label class="field"><span>年份</span><input type="text" id="paYear" placeholder="2026" /></label>
          <label class="field"><span>期刊 / 来源</span><input type="text" id="paJournal" placeholder="期刊名" /></label>
        </div>
        <label class="field"><span>链接（可选）</span><input type="text" id="paLink" placeholder="https://…" /></label>
        <label class="field"><span>笔记 / 摘要</span><textarea id="paNote" placeholder="关键结论、你的想法…"></textarea></label>
        <div class="btn-row"><button class="btn" id="paAdd">加入文献库</button></div>
        <div id="paList" style="margin-top:14px">`;
      if (!papers.length) html += `<div class="empty">文献库为空</div>`;
      papers.slice().reverse().forEach((p) => {
        html += `<div class="item">
          <div class="grow">
            <div class="title">${u.esc(p.title)} ${p.year ? `<span class="meta">(${u.esc(p.year)})</span>` : ''}</div>
            <div class="meta">${u.esc([p.author, p.journal].filter(Boolean).join(' · '))}</div>
            ${p.note ? `<div class="meta">📝 ${u.esc(p.note)}</div>` : ''}
            ${p.link ? `<div class="meta"><a href="${u.esc(p.link)}" target="_blank" rel="noopener">查看原文 ↗</a></div>` : ''}
          </div>
          <div class="item-actions"><button class="btn ghost sm" data-del-pa="${p.id}">删除</button></div>
        </div>`;
      });
      html += `</div></div>`;

      // ---- ③ 实验待办 ----
      const expLeft = expTodos.filter((t) => !t.done).length;
      html += `<div class="card">
        <div class="card-title">🧪 实验待办 <span class="badge tag">待办 ${expLeft}</span></div>
        <div class="btn-row" style="margin-bottom:12px">
          <input type="text" id="eText" placeholder="如：配制 0.1M 缓冲液" style="flex:1" />
          <button class="btn" id="eAdd">添加</button>
        </div>
        <div id="eList">`;
      if (!expTodos.length) html += `<div class="empty">暂无实验待办</div>`;
      expTodos.forEach((t) => {
        html += `<div class="item ${t.done ? 'done' : ''}">
          <div class="check ${t.done ? 'on' : ''}" data-toggle-e="${t.id}">${t.done ? '✓' : ''}</div>
          <div class="grow"><div class="title">${u.esc(t.text)}</div></div>
          <div class="item-actions"><button class="btn ghost sm" data-del-e="${t.id}">删除</button></div>
        </div>`;
      });
      html += `</div></div>`;

      html += `</div>`; // .view
      c.innerHTML = html;

      // ---- 事件绑定 ----
      // 项目
      c.querySelector('#pAdd').addEventListener('click', () => {
        const name = c.querySelector('#pName').value.trim();
        if (!name) return YH.toast('请填写项目名称');
        projects.push({ id: u.uid(), name, desc: c.querySelector('#pDesc').value.trim(), createdAt: Date.now() });
        YH.store.set('projects', projects); YH.refresh();
      });
      c.querySelectorAll('[data-del-p]').forEach((b) => b.addEventListener('click', () => {
        YH.store.set('projects', projects.filter((x) => x.id !== b.dataset.delP)); YH.refresh();
      }));
      // 文献
      c.querySelector('#paAdd').addEventListener('click', () => {
        const title = c.querySelector('#paTitle').value.trim();
        if (!title) return YH.toast('请填写文献标题');
        papers.push({
          id: u.uid(), title,
          author: c.querySelector('#paAuthor').value.trim(),
          year: c.querySelector('#paYear').value.trim(),
          journal: c.querySelector('#paJournal').value.trim(),
          link: c.querySelector('#paLink').value.trim(),
          note: c.querySelector('#paNote').value.trim()
        });
        YH.store.set('papers', papers); YH.refresh();
      });
      c.querySelectorAll('[data-del-pa]').forEach((b) => b.addEventListener('click', () => {
        YH.store.set('papers', papers.filter((x) => x.id !== b.dataset.delPa)); YH.refresh();
      }));
      // 实验待办
      c.querySelector('#eAdd').addEventListener('click', () => {
        const text = c.querySelector('#eText').value.trim();
        if (!text) return YH.toast('请填写待办内容');
        expTodos.push({ id: u.uid(), text, done: false, createdAt: Date.now() });
        YH.store.set('expTodos', expTodos); YH.refresh();
      });
      c.querySelectorAll('[data-toggle-e]').forEach((b) => b.addEventListener('click', () => {
        const t = expTodos.find((x) => x.id === b.dataset.toggleE);
        if (t) { t.done = !t.done; YH.store.set('expTodos', expTodos); YH.refresh(); }
      }));
      c.querySelectorAll('[data-del-e]').forEach((b) => b.addEventListener('click', () => {
        YH.store.set('expTodos', expTodos.filter((x) => x.id !== b.dataset.delE)); YH.refresh();
      }));
    }
  };
})(window.YH);
