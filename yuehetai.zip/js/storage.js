/* =========================================================================
   月禾台 · 本地存储层
   所有数据保存在浏览器 localStorage（key 统一加 yh_ 前缀，便于整体导出/清空）
   暴露全局对象 YH.store
   ========================================================================= */
window.YH = window.YH || {};

YH.store = (function () {
  const PREFIX = 'yh_';

  function get(key, fallback) {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      return raw == null ? fallback : JSON.parse(raw);
    } catch (e) {
      console.warn('读取本地数据失败：', key, e);
      return fallback;
    }
  }

  function set(key, value) {
    try {
      localStorage.setItem(PREFIX + key, JSON.stringify(value));
    } catch (e) {
      alert('保存失败，可能存储空间已满：' + e.message);
    }
  }

  // 导出全部数据（用于「设置 → 导出」）
  function exportAll() {
    const out = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(PREFIX)) {
        out[k.slice(PREFIX.length)] = JSON.parse(localStorage.getItem(k));
      }
    }
    return out;
  }

  // 导入数据（覆盖写入）
  function importAll(obj) {
    Object.keys(obj).forEach((k) => set(k, obj[k]));
  }

  // 清空全部（用于「设置 → 清空本地数据」）
  function clearAll() {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(PREFIX)) keys.push(k);
    }
    keys.forEach((k) => localStorage.removeItem(k));
  }

  return { get, set, exportAll, importAll, clearAll };
})();
